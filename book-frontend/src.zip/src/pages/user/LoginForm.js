import React from 'react';

const LoginForm = () => {
  return (
    <div>
      <h1>로그인 창</h1>
    </div>
  );
};

export default LoginForm;
