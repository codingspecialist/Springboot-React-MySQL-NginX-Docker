import React from 'react';

const JoinForm = () => {
  return (
    <div>
      <h1>회원가입 폼</h1>
    </div>
  );
};

export default JoinForm;
